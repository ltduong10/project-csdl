--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.incategory DROP CONSTRAINT incategory_product_fkey;
ALTER TABLE ONLY public.incategory DROP CONSTRAINT incategory_category_fkey;
ALTER TABLE ONLY public.addtowishlist DROP CONSTRAINT addtowishlist_productid_fkey;
ALTER TABLE ONLY public.addtowishlist DROP CONSTRAINT addtowishlist_customerid_fkey;
ALTER TABLE ONLY public.addtocart DROP CONSTRAINT addtocart_productid_fkey;
ALTER TABLE ONLY public.addtocart DROP CONSTRAINT addtocart_customerid_fkey;
ALTER TABLE ONLY public.subimage DROP CONSTRAINT subimage_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_productname_key;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.incategory DROP CONSTRAINT incategory_pkey;
ALTER TABLE ONLY public.customers DROP CONSTRAINT customers_username_key;
ALTER TABLE ONLY public.customers DROP CONSTRAINT customers_pkey;
ALTER TABLE ONLY public.customers DROP CONSTRAINT customers_phone_key;
ALTER TABLE ONLY public.customers DROP CONSTRAINT customers_email_key;
ALTER TABLE ONLY public.categories DROP CONSTRAINT categories_pkey;
ALTER TABLE ONLY public.categories DROP CONSTRAINT categories_categoryname_key;
ALTER TABLE ONLY public.addtowishlist DROP CONSTRAINT addtowishlist_pkey;
ALTER TABLE ONLY public.addtocart DROP CONSTRAINT addtocart_pkey;
ALTER TABLE public.products ALTER COLUMN productid DROP DEFAULT;
ALTER TABLE public.customers ALTER COLUMN userid DROP DEFAULT;
ALTER TABLE public.categories ALTER COLUMN categoryid DROP DEFAULT;
DROP TABLE public.subimage;
DROP SEQUENCE public.products_productid_seq;
DROP TABLE public.products;
DROP TABLE public.incategory;
DROP SEQUENCE public.customers_userid_seq;
DROP TABLE public.customers;
DROP SEQUENCE public.categories_categoryid_seq;
DROP TABLE public.categories;
DROP TABLE public.addtowishlist;
DROP TABLE public.addtocart;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: addtocart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.addtocart (
    customerid bigint NOT NULL,
    productid bigint NOT NULL,
    amount bigint NOT NULL
);


ALTER TABLE public.addtocart OWNER TO postgres;

--
-- Name: addtowishlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.addtowishlist (
    customerid bigint NOT NULL,
    productid bigint NOT NULL
);


ALTER TABLE public.addtowishlist OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    categoryid bigint NOT NULL,
    categoryname text NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_categoryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_categoryid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_categoryid_seq OWNER TO postgres;

--
-- Name: categories_categoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_categoryid_seq OWNED BY public.categories.categoryid;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    userid bigint NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    address text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_userid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_userid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_userid_seq OWNER TO postgres;

--
-- Name: customers_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_userid_seq OWNED BY public.customers.userid;


--
-- Name: incategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incategory (
    product bigint NOT NULL,
    category bigint NOT NULL
);


ALTER TABLE public.incategory OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    productid bigint NOT NULL,
    productname text NOT NULL,
    price bigint NOT NULL,
    image text NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_productid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_productid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_productid_seq OWNER TO postgres;

--
-- Name: products_productid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_productid_seq OWNED BY public.products.productid;


--
-- Name: subimage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subimage (
    productid bigint NOT NULL,
    image text NOT NULL
);


ALTER TABLE public.subimage OWNER TO postgres;

--
-- Name: categories categoryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN categoryid SET DEFAULT nextval('public.categories_categoryid_seq'::regclass);


--
-- Name: customers userid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN userid SET DEFAULT nextval('public.customers_userid_seq'::regclass);


--
-- Name: products productid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN productid SET DEFAULT nextval('public.products_productid_seq'::regclass);


--
-- Data for Name: addtocart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.addtocart (customerid, productid, amount) FROM stdin;
\.
COPY public.addtocart (customerid, productid, amount) FROM '$$PATH$$/2864.dat';

--
-- Data for Name: addtowishlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.addtowishlist (customerid, productid) FROM stdin;
\.
COPY public.addtowishlist (customerid, productid) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (categoryid, categoryname) FROM stdin;
\.
COPY public.categories (categoryid, categoryname) FROM '$$PATH$$/2857.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (userid, username, password, address, phone, email) FROM stdin;
\.
COPY public.customers (userid, username, password, address, phone, email) FROM '$$PATH$$/2859.dat';

--
-- Data for Name: incategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incategory (product, category) FROM stdin;
\.
COPY public.incategory (product, category) FROM '$$PATH$$/2862.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (productid, productname, price, image, description) FROM stdin;
\.
COPY public.products (productid, productname, price, image, description) FROM '$$PATH$$/2861.dat';

--
-- Data for Name: subimage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subimage (productid, image) FROM stdin;
\.
COPY public.subimage (productid, image) FROM '$$PATH$$/2863.dat';

--
-- Name: categories_categoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_categoryid_seq', 8, true);


--
-- Name: customers_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_userid_seq', 7, true);


--
-- Name: products_productid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_productid_seq', 2, true);


--
-- Name: addtocart addtocart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addtocart
    ADD CONSTRAINT addtocart_pkey PRIMARY KEY (customerid, productid);


--
-- Name: addtowishlist addtowishlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addtowishlist
    ADD CONSTRAINT addtowishlist_pkey PRIMARY KEY (customerid, productid);


--
-- Name: categories categories_categoryname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_categoryname_key UNIQUE (categoryname);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (categoryid);


--
-- Name: customers customers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_email_key UNIQUE (email);


--
-- Name: customers customers_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_phone_key UNIQUE (phone);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (userid);


--
-- Name: customers customers_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_username_key UNIQUE (username);


--
-- Name: incategory incategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incategory
    ADD CONSTRAINT incategory_pkey PRIMARY KEY (product, category);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (productid);


--
-- Name: products products_productname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_productname_key UNIQUE (productname);


--
-- Name: subimage subimage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subimage
    ADD CONSTRAINT subimage_pkey PRIMARY KEY (productid, image);


--
-- Name: addtocart addtocart_customerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addtocart
    ADD CONSTRAINT addtocart_customerid_fkey FOREIGN KEY (customerid) REFERENCES public.customers(userid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: addtocart addtocart_productid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addtocart
    ADD CONSTRAINT addtocart_productid_fkey FOREIGN KEY (productid) REFERENCES public.products(productid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: addtowishlist addtowishlist_customerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addtowishlist
    ADD CONSTRAINT addtowishlist_customerid_fkey FOREIGN KEY (customerid) REFERENCES public.customers(userid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: addtowishlist addtowishlist_productid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addtowishlist
    ADD CONSTRAINT addtowishlist_productid_fkey FOREIGN KEY (productid) REFERENCES public.products(productid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: incategory incategory_category_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incategory
    ADD CONSTRAINT incategory_category_fkey FOREIGN KEY (category) REFERENCES public.categories(categoryid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: incategory incategory_product_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incategory
    ADD CONSTRAINT incategory_product_fkey FOREIGN KEY (product) REFERENCES public.products(productid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

